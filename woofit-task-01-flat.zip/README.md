# WoofFit AI — Task 01 (Scaffold + CI)
Repo-ready Flutter scaffold with CI workflow. Upload via GitHub web.
